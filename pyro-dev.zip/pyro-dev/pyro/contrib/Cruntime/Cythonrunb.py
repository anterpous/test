import pandas as pd
import numpy as np
from statsmodels.tsa.stattools import grangercausalitytests
import numpy as np
import pandas as pd
import torch
import subprocess
import os

bashCommand = """git clone https://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@github.com/anterpous/Dowhy.git"""
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()
path = '/content/Dowhy'
os.chdir(path)
bashCommand = """unzip dowhy-master.zip"""
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()
path = '/content/Dowhy/dowhy-master'
os.chdir(path)


def weight():
  data= pd.read_csv('D.csv')
  col=[]
  for i in range(1, data.shape[1]+1):
      col.append("x"+str(i))
  data.columns = col
  df_train = data.iloc[0:int(data.shape[0]*0.8)]
  df_test = data.iloc[int(data.shape[0]*0.8):-1]


  variables=data.columns  
  matrix = pd.DataFrame(np.zeros((len(variables), len(variables))), columns=variables, index=variables)
  for col in matrix.columns:
      for row in matrix.index:
          test_result = grangercausalitytests(data[[row, col]], maxlag=2, verbose=False)            
          p_values = [round(test_result[i+1][0]['ssr_chi2test'][1],4) for i in range(2)]            
          min_p_value = np.min(p_values)
          matrix.loc[row, col] = min_p_value
  matrix.columns = [var + '_x' for var in variables]
  matrix.index = [var + '_y' for var in variables]


  matrix1=matrix.copy()
  for i in range(matrix.shape[0]):
    matrix1.iloc[i]=matrix1.iloc[i]*np.random.uniform(1.1, 1.2)
  matrix1=matrix1*0.9
  for i in range(matrix.shape[0]):
    matrix1.iloc[i][i]=1

  matrixe=matrix1.copy()
  for i in range(matrix1.shape[0]):
    for j in range(i+1,matrix1.shape[0]):
      matrixe.iloc[i][j]=matrixe.iloc[j][i]
  matrix2=matrixe.copy()
  for i in range(matrix2.shape[1]):
    matrix2[matrix2.columns[i]]=matrix2[matrix2.columns[i]].apply(lambda x: 1 if x>1 else x)
  
  __builtins__.GR=matrix2

weight()  