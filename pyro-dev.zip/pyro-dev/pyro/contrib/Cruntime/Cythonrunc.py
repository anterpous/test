import subprocess
import os

bashCommand = """git clone https://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@github.com/anterpous/Dowhy.git"""
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()
path = '/content/Dowhy'
os.chdir(path)
bashCommand = """unzip dowhy-master.zip"""
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()
path = '/content/Dowhy/dowhy-master'
os.chdir(path)
bashCommand = """python setup.py install"""
process = subprocess.Popen(bashCommand.split(), stdout=subprocess.PIPE)
output, error = process.communicate()
import pandas as pd
import numpy as np
import dowhy
from dowhy import CausalModel
from dowhy import causal_estimators
model=CausalModel(
        data = __builtins__.data,
        treatment='treatment',
        outcome='y_factual',
        common_causes='16'
        )

identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)
estimate = model.estimate_effect(identified_estimand,
        method_name="backdoor.linear_regression", test_significance=True
)
__builtins__.Dout = float(str(estimate))