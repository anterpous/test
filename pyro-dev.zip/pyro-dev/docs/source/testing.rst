Testing Utilities
-----------------

.. automodule:: pyro.distributions.testing.gof
   :members:
   :member-order: bysource
